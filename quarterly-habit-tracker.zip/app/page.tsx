"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Trash2,
  X,
  Target,
  Calendar,
  TrendingUp,
  Award,
  BarChart3,
} from "lucide-react"

interface Habit {
  id: string
  name: string
  completions: boolean[]
}

interface Goal {
  id: string
  name: string
  description: string
  completed: boolean
}

interface QuarterData {
  [key: string]: Habit[]
}

interface GoalData {
  [key: string]: Goal[]
}

const QUARTERS = [
  { id: "Q1", name: "Q1 2025", months: ["January", "February", "March"] },
  { id: "Q2", name: "Q2 2025", months: ["April", "May", "June"] },
  { id: "Q3", name: "Q3 2025", months: ["July", "August", "September"] },
  { id: "Q4", name: "Q4 2025", months: ["October", "November", "December"] },
]

const getDaysInQuarter = (quarterId: string): number => {
  // Simplified: assume 90 days per quarter for consistent grid
  return 90
}

const getCurrentDayOfQuarter = (): number => {
  const now = new Date()
  const year = now.getFullYear()
  const month = now.getMonth() // 0-based
  const day = now.getDate()

  // Determine which quarter we're in and calculate day
  let quarterStart: Date
  if (month >= 0 && month <= 2) {
    // Q1: Jan-Mar
    quarterStart = new Date(year, 0, 1)
  } else if (month >= 3 && month <= 5) {
    // Q2: Apr-Jun
    quarterStart = new Date(year, 3, 1)
  } else if (month >= 6 && month <= 8) {
    // Q3: Jul-Sep
    quarterStart = new Date(year, 6, 1)
  } else {
    // Q4: Oct-Dec
    quarterStart = new Date(year, 9, 1)
  }

  const diffTime = now.getTime() - quarterStart.getTime()
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24)) + 1
  return Math.min(Math.max(diffDays, 1), 90) // Ensure between 1-90 days
}

const getCurrentQuarter = (): string => {
  const now = new Date()
  const month = now.getMonth() // 0-based

  if (month >= 0 && month <= 2) return "Q1"
  if (month >= 3 && month <= 5) return "Q2"
  if (month >= 6 && month <= 8) return "Q3"
  return "Q4"
}

const getCurrentMonthInQuarter = (): number => {
  const now = new Date()
  const month = now.getMonth() // 0-based

  if (month >= 0 && month <= 2) return month // 0, 1, 2 for Jan, Feb, Mar
  if (month >= 3 && month <= 5) return month - 3 // 0, 1, 2 for Apr, May, Jun
  if (month >= 6 && month <= 8) return month - 6 // 0, 1, 2 for Jul, Aug, Sep
  return month - 9 // 0, 1, 2 for Oct, Nov, Dec
}

export default function HabitTracker() {
  const [currentQuarter, setCurrentQuarter] = useState(getCurrentQuarter())
  const [currentMonth, setCurrentMonth] = useState(getCurrentMonthInQuarter())
  const [activeTab, setActiveTab] = useState("habits")
  const [quarterData, setQuarterData] = useState<QuarterData>({})
  const [goalData, setGoalData] = useState<GoalData>({})
  const [newGoalName, setNewGoalName] = useState("")
  const [newGoalDescription, setNewGoalDescription] = useState("")
  const [newHabitName, setNewHabitName] = useState("")

  const currentDay = getCurrentDayOfQuarter()

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem("habitTrackerData")
    const savedGoals = localStorage.getItem("goalTrackerData")
    if (savedData) {
      setQuarterData(JSON.parse(savedData))
    }
    if (savedGoals) {
      setGoalData(JSON.parse(savedGoals))
    }
  }, [])

  // Save data to localStorage whenever quarterData changes
  useEffect(() => {
    localStorage.setItem("habitTrackerData", JSON.stringify(quarterData))
  }, [quarterData])

  useEffect(() => {
    localStorage.setItem("goalTrackerData", JSON.stringify(goalData))
  }, [goalData])

  const currentHabits = quarterData[currentQuarter] || []
  const currentGoals = goalData[currentQuarter] || []
  const daysInQuarter = getDaysInQuarter(currentQuarter)

  const addHabit = () => {
    if (!newHabitName.trim()) return

    const newHabit: Habit = {
      id: Date.now().toString(),
      name: newHabitName.trim(),
      completions: new Array(daysInQuarter).fill(false),
    }

    setQuarterData((prev) => ({
      ...prev,
      [currentQuarter]: [...(prev[currentQuarter] || []), newHabit],
    }))

    setNewHabitName("")
  }

  const deleteHabit = (habitId: string) => {
    setQuarterData((prev) => ({
      ...prev,
      [currentQuarter]: (prev[currentQuarter] || []).filter((h) => h.id !== habitId),
    }))
  }

  const toggleCompletion = (habitId: string, dayIndex: number) => {
    setQuarterData((prev) => ({
      ...prev,
      [currentQuarter]: (prev[currentQuarter] || []).map((habit) =>
        habit.id === habitId
          ? {
              ...habit,
              completions: habit.completions.map((completed, index) => (index === dayIndex ? !completed : completed)),
            }
          : habit,
      ),
    }))
  }

  const navigateQuarter = (direction: "prev" | "next") => {
    const currentIndex = QUARTERS.findIndex((q) => q.id === currentQuarter)
    if (direction === "prev" && currentIndex > 0) {
      setCurrentQuarter(QUARTERS[currentIndex - 1].id)
      setCurrentMonth(0)
    } else if (direction === "next" && currentIndex < QUARTERS.length - 1) {
      setCurrentQuarter(QUARTERS[currentIndex + 1].id)
      setCurrentMonth(0)
    }
  }

  const navigateMonth = (direction: "prev" | "next") => {
    if (direction === "prev" && currentMonth > 0) {
      setCurrentMonth(currentMonth - 1)
    } else if (direction === "next" && currentMonth < 2) {
      setCurrentMonth(currentMonth + 1)
    }
  }

  const addGoal = () => {
    if (!newGoalName.trim()) return

    const newGoal: Goal = {
      id: Date.now().toString(),
      name: newGoalName.trim(),
      description: newGoalDescription.trim(),
      completed: false,
    }

    setGoalData((prev) => ({
      ...prev,
      [currentQuarter]: [...(prev[currentQuarter] || []), newGoal],
    }))

    setNewGoalName("")
    setNewGoalDescription("")
  }

  const deleteGoal = (goalId: string) => {
    setGoalData((prev) => ({
      ...prev,
      [currentQuarter]: (prev[currentQuarter] || []).filter((g) => g.id !== goalId),
    }))
  }

  const toggleGoalCompletion = (goalId: string) => {
    setGoalData((prev) => ({
      ...prev,
      [currentQuarter]: (prev[currentQuarter] || []).map((goal) =>
        goal.id === goalId ? { ...goal, completed: !goal.completed } : goal,
      ),
    }))
  }

  const currentQuarterInfo = QUARTERS.find((q) => q.id === currentQuarter)

  const getHabitProgress = (habit: Habit) => {
    const completed = habit.completions.filter(Boolean).length
    const total = Math.min(currentDay, habit.completions.length)
    return { completed, total, percentage: total > 0 ? Math.round((completed / total) * 100) : 0 }
  }

  const getOverallProgress = () => {
    if (currentHabits.length === 0) return { completed: 0, total: 0, percentage: 0 }

    const totalCompleted = currentHabits.reduce((sum, habit) => {
      return sum + habit.completions.slice(0, currentDay).filter(Boolean).length
    }, 0)

    const totalPossible = currentHabits.length * currentDay
    return {
      completed: totalCompleted,
      total: totalPossible,
      percentage: totalPossible > 0 ? Math.round((totalCompleted / totalPossible) * 100) : 0,
    }
  }

  const getGoalProgress = () => {
    const completed = currentGoals.filter((goal) => goal.completed).length
    const total = currentGoals.length
    return { completed, total, percentage: total > 0 ? Math.round((completed / total) * 100) : 0 }
  }

  const getComprehensiveStats = () => {
    const allQuarters = Object.keys(quarterData)
    const totalHabits = allQuarters.reduce((sum, quarter) => sum + (quarterData[quarter]?.length || 0), 0)

    const totalGoals = Object.keys(goalData).reduce((sum, quarter) => sum + (goalData[quarter]?.length || 0), 0)
    const completedGoals = Object.keys(goalData).reduce((sum, quarter) => {
      return sum + (goalData[quarter]?.filter((goal) => goal.completed).length || 0)
    }, 0)

    const currentQuarterHabits = currentHabits.length
    const currentQuarterGoals = currentGoals.length
    const currentQuarterCompletedGoals = currentGoals.filter((goal) => goal.completed).length

    // Calculate streak data for current quarter
    const streakData = currentHabits.map((habit) => {
      let currentStreak = 0
      let longestStreak = 0
      let tempStreak = 0

      for (let i = 0; i < Math.min(currentDay, habit.completions.length); i++) {
        if (habit.completions[i]) {
          tempStreak++
          longestStreak = Math.max(longestStreak, tempStreak)
          if (i === Math.min(currentDay, habit.completions.length) - 1) {
            currentStreak = tempStreak
          }
        } else {
          tempStreak = 0
          if (i === Math.min(currentDay, habit.completions.length) - 1) {
            currentStreak = 0
          }
        }
      }

      return {
        name: habit.name,
        currentStreak,
        longestStreak,
        completionRate: getHabitProgress(habit).percentage,
      }
    })

    return {
      totalHabits,
      totalGoals,
      completedGoals,
      currentQuarterHabits,
      currentQuarterGoals,
      currentQuarterCompletedGoals,
      streakData,
      overallProgress: getOverallProgress(),
      goalProgress: getGoalProgress(),
    }
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <nav className="border-b border-slate-700 bg-slate-800/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="mx-auto max-w-7xl px-4 md:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <Calendar className="h-6 w-6 text-emerald-400" />
                <h2 className="text-xl font-bold text-white">Habit Tracker</h2>
              </div>
              <div className="flex gap-1 bg-slate-700/50 rounded-lg p-1">
                <Button
                  variant={activeTab === "habits" ? "default" : "ghost"}
                  onClick={() => setActiveTab("habits")}
                  className={`text-sm transition-all duration-200 ${
                    activeTab === "habits"
                      ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg"
                      : "text-slate-300 hover:bg-slate-600 hover:text-white"
                  }`}
                >
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Habits
                </Button>
                <Button
                  variant={activeTab === "goals" ? "default" : "ghost"}
                  onClick={() => setActiveTab("goals")}
                  className={`text-sm transition-all duration-200 ${
                    activeTab === "goals"
                      ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg"
                      : "text-slate-300 hover:bg-slate-600 hover:text-white"
                  }`}
                >
                  <Target className="h-4 w-4 mr-2" />
                  Goals
                </Button>
                <Button
                  variant={activeTab === "stats" ? "default" : "ghost"}
                  onClick={() => setActiveTab("stats")}
                  className={`text-sm transition-all duration-200 ${
                    activeTab === "stats"
                      ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg"
                      : "text-slate-300 hover:bg-slate-600 hover:text-white"
                  }`}
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Stats
                </Button>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-4 text-sm">
              {activeTab === "habits" ? (
                <div className="flex items-center gap-2 text-slate-300">
                  <Award className="h-4 w-4 text-emerald-400" />
                  <span>{getOverallProgress().percentage}% Complete</span>
                </div>
              ) : activeTab === "goals" ? (
                <div className="flex items-center gap-2 text-slate-300">
                  <Target className="h-4 w-4 text-emerald-400" />
                  <span>
                    {getGoalProgress().completed}/{getGoalProgress().total} Goals
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-slate-300">
                  <BarChart3 className="h-4 w-4 text-emerald-400" />
                  <span>Analytics Overview</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      <div className="p-4 md:p-8">
        <div className="mx-auto max-w-7xl">
          {activeTab === "stats" ? (
            <>
              {/* Stats Header */}
              <div className="mb-8 flex flex-col items-center gap-6">
                <div className="flex items-center gap-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigateQuarter("prev")}
                    disabled={currentQuarter === "Q1"}
                    className="text-slate-300 hover:bg-slate-800 hover:text-white transition-all duration-200 hover:scale-105"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>

                  <div className="text-center">
                    <h1 className="text-3xl font-bold text-white mb-1">{currentQuarterInfo?.name} Analytics</h1>
                    <p className="text-slate-400 text-sm">Track your progress and insights</p>
                  </div>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigateQuarter("next")}
                    disabled={currentQuarter === "Q4"}
                    className="text-slate-300 hover:bg-slate-800 hover:text-white transition-all duration-200 hover:scale-105"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              {/* Stats Dashboard */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {(() => {
                  const stats = getComprehensiveStats()
                  return (
                    <>
                      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
                        <div className="flex items-center gap-3 mb-2">
                          <TrendingUp className="h-5 w-5 text-emerald-400" />
                          <h3 className="font-semibold text-white">Current Progress</h3>
                        </div>
                        <div className="text-3xl font-bold text-emerald-400 mb-1">
                          {stats.overallProgress.percentage}%
                        </div>
                        <p className="text-sm text-slate-400">
                          {stats.overallProgress.completed} of {stats.overallProgress.total} completions
                        </p>
                      </div>

                      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
                        <div className="flex items-center gap-3 mb-2">
                          <Calendar className="h-5 w-5 text-blue-400" />
                          <h3 className="font-semibold text-white">Active Habits</h3>
                        </div>
                        <div className="text-3xl font-bold text-blue-400 mb-1">{stats.currentQuarterHabits}</div>
                        <p className="text-sm text-slate-400">This quarter</p>
                      </div>

                      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
                        <div className="flex items-center gap-3 mb-2">
                          <Target className="h-5 w-5 text-purple-400" />
                          <h3 className="font-semibold text-white">Goals Progress</h3>
                        </div>
                        <div className="text-3xl font-bold text-purple-400 mb-1">{stats.goalProgress.percentage}%</div>
                        <p className="text-sm text-slate-400">
                          {stats.currentQuarterCompletedGoals} of {stats.currentQuarterGoals} completed
                        </p>
                      </div>

                      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
                        <div className="flex items-center gap-3 mb-2">
                          <Award className="h-5 w-5 text-yellow-400" />
                          <h3 className="font-semibold text-white">Current Day</h3>
                        </div>
                        <div className="text-3xl font-bold text-yellow-400 mb-1">{currentDay}</div>
                        <p className="text-sm text-slate-400">of 90 days</p>
                      </div>
                    </>
                  )
                })()}
              </div>

              {/* Habit Performance */}
              {(() => {
                const stats = getComprehensiveStats()
                return stats.streakData.length > 0 ? (
                  <div className="bg-slate-800/30 rounded-xl p-6 mb-8">
                    <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-emerald-400" />
                      Habit Performance
                    </h3>
                    <div className="grid gap-4">
                      {stats.streakData.map((habit, index) => (
                        <div key={index} className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="font-semibold text-white">{habit.name}</h4>
                            <div className="text-sm text-emerald-400 font-medium">{habit.completionRate}%</div>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-slate-400">Current Streak: </span>
                              <span className="text-white font-medium">{habit.currentStreak} days</span>
                            </div>
                            <div>
                              <span className="text-slate-400">Best Streak: </span>
                              <span className="text-white font-medium">{habit.longestStreak} days</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-16 text-slate-400">
                    <BarChart3 className="h-20 w-20 mx-auto mb-6 text-slate-500" />
                    <p className="text-xl font-medium mb-2">No data to analyze yet</p>
                    <p className="text-sm">Start tracking habits to see your performance analytics!</p>
                  </div>
                )
              })()}

              {/* All-Time Overview */}
              {(() => {
                const stats = getComprehensiveStats()
                return (
                  <div className="bg-slate-800/30 rounded-xl p-6">
                    <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                      <Award className="h-5 w-5 text-yellow-400" />
                      All-Time Overview
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-emerald-400 mb-1">{stats.totalHabits}</div>
                        <p className="text-sm text-slate-400">Total Habits Created</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-400 mb-1">{stats.totalGoals}</div>
                        <p className="text-sm text-slate-400">Total Goals Set</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-yellow-400 mb-1">{stats.completedGoals}</div>
                        <p className="text-sm text-slate-400">Goals Achieved</p>
                      </div>
                    </div>
                  </div>
                )
              })()}
            </>
          ) : activeTab === "habits" ? (
            <>
              {/* Header with Quarter Navigation */}
              <div className="mb-8 flex flex-col items-center gap-6">
                <div className="flex items-center gap-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigateQuarter("prev")}
                    disabled={currentQuarter === "Q1"}
                    className="text-slate-300 hover:bg-slate-800 hover:text-white transition-all duration-200 hover:scale-105"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>

                  <div className="text-center">
                    <h1 className="text-3xl font-bold text-white mb-1">{currentQuarterInfo?.name}</h1>
                    <p className="text-slate-400 text-sm">Day {currentDay} of 90</p>
                  </div>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigateQuarter("next")}
                    disabled={currentQuarter === "Q4"}
                    className="text-slate-300 hover:bg-slate-800 hover:text-white transition-all duration-200 hover:scale-105"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </div>

                <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg px-4 py-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateMonth("prev")}
                    disabled={currentMonth === 0}
                    className="text-slate-400 hover:bg-slate-700 hover:text-white transition-all duration-200"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>

                  <span className="text-lg font-medium text-emerald-300 min-w-[120px] text-center">
                    {currentQuarterInfo?.months[currentMonth]}
                  </span>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateMonth("next")}
                    disabled={currentMonth === 2}
                    className="text-slate-400 hover:bg-slate-700 hover:text-white transition-all duration-200"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>

                {currentHabits.length > 0 && (
                  <div className="flex items-center gap-6 text-sm">
                    <div className="bg-slate-800/50 rounded-lg px-4 py-2">
                      <span className="text-slate-400">Overall Progress: </span>
                      <span className="text-emerald-400 font-semibold">{getOverallProgress().percentage}%</span>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg px-4 py-2">
                      <span className="text-slate-400">Habits: </span>
                      <span className="text-white font-semibold">{currentHabits.length}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Add Habit Form */}
              <div className="mb-8 flex justify-center">
                <div className="flex w-full max-w-md gap-2">
                  <Input
                    placeholder="Add a new habit..."
                    value={newHabitName}
                    onChange={(e) => setNewHabitName(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addHabit()}
                    className="bg-slate-800/80 text-white border-slate-600 focus:border-emerald-500 placeholder:text-slate-400 transition-all duration-200 focus:ring-2 focus:ring-emerald-500/20"
                  />
                  <Button
                    onClick={addHabit}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white transition-all duration-200 hover:scale-105 shadow-lg hover:shadow-emerald-500/25"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Habits Grid */}
              <div className="overflow-x-auto">
                <div className="min-w-fit">
                  {/* Header Row */}
                  <div className="mb-4 grid grid-cols-[250px_repeat(30,1fr)_80px_80px] gap-1 text-sm">
                    <div className="font-semibold text-white">Habits</div>
                    {Array.from({ length: 30 }, (_, i) => (
                      <div
                        key={i}
                        className={`text-center font-medium transition-all duration-200 ${
                          i + 1 === currentDay
                            ? "text-emerald-400 font-bold scale-110"
                            : i + 1 < currentDay
                              ? "text-slate-300"
                              : "text-slate-500"
                        }`}
                      >
                        {i + 1}
                      </div>
                    ))}
                    <div className="text-center text-slate-400 font-medium">Progress</div>
                    <div className="text-center text-slate-400 font-medium">Delete</div>
                  </div>

                  {/* Habit Rows */}
                  {currentHabits.map((habit) => {
                    const progress = getHabitProgress(habit)
                    return (
                      <div
                        key={habit.id}
                        className="mb-3 grid grid-cols-[250px_repeat(30,1fr)_80px_80px] gap-1 items-center bg-slate-800/30 rounded-lg p-2 hover:bg-slate-800/50 transition-all duration-200"
                      >
                        <div className="text-white font-medium truncate pr-2">{habit.name}</div>

                        {Array.from({ length: 30 }, (_, dayIndex) => (
                          <button
                            key={dayIndex}
                            onClick={() => toggleCompletion(habit.id, dayIndex)}
                            disabled={dayIndex >= currentDay}
                            className={`h-8 w-8 flex items-center justify-center rounded-lg border transition-all duration-200 hover:scale-110 ${
                              dayIndex + 1 === currentDay
                                ? "border-emerald-500 bg-emerald-500/20 hover:bg-emerald-500/30 shadow-lg shadow-emerald-500/25 ring-2 ring-emerald-500/50"
                                : dayIndex < currentDay
                                  ? habit.completions[dayIndex]
                                    ? "border-emerald-500 bg-emerald-500/40 hover:bg-emerald-500/50"
                                    : "border-red-500/50 bg-red-500/10 hover:bg-red-500/20"
                                  : "border-slate-600 bg-slate-700/50 cursor-not-allowed opacity-50"
                            }`}
                          >
                            {habit.completions[dayIndex] && <X className="h-4 w-4 text-emerald-400" />}
                          </button>
                        ))}

                        <div className="text-center">
                          <div className="text-xs text-slate-400">{progress.percentage}%</div>
                          <div className="text-xs text-slate-500">
                            {progress.completed}/{progress.total}
                          </div>
                        </div>

                        <div className="flex justify-center">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteHabit(habit.id)}
                            className="h-8 w-8 text-red-400 hover:bg-red-500/20 hover:text-red-300 transition-all duration-200 hover:scale-110"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    )
                  })}

                  {currentHabits.length === 0 && (
                    <div className="text-center py-16 text-slate-400">
                      <TrendingUp className="h-16 w-16 mx-auto mb-4 text-slate-500" />
                      <p className="text-xl font-medium mb-2">No habits yet for {currentQuarterInfo?.name}</p>
                      <p className="text-sm">Add your first habit above to start building consistency!</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Quarter Info */}
              <div className="mt-12 text-center text-sm text-slate-400 bg-slate-800/30 rounded-lg p-4">
                <p className="font-medium">Tracking habits for {currentQuarterInfo?.months.join(", ")}</p>
                <p className="mt-1">Each quarter starts with a clean slate • Build consistency day by day</p>
              </div>
            </>
          ) : (
            <>
              {/* Header with Quarter Navigation */}
              <div className="mb-8 flex flex-col items-center gap-6">
                <div className="flex items-center gap-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigateQuarter("prev")}
                    disabled={currentQuarter === "Q1"}
                    className="text-slate-300 hover:bg-slate-800 hover:text-white transition-all duration-200 hover:scale-105"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>

                  <div className="text-center">
                    <h1 className="text-3xl font-bold text-white mb-1">{currentQuarterInfo?.name} Goals</h1>
                    <p className="text-slate-400 text-sm">Set your quarterly objectives</p>
                  </div>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigateQuarter("next")}
                    disabled={currentQuarter === "Q4"}
                    className="text-slate-300 hover:bg-slate-800 hover:text-white transition-all duration-200 hover:scale-105"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </div>

                <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg px-4 py-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateMonth("prev")}
                    disabled={currentMonth === 0}
                    className="text-slate-400 hover:bg-slate-700 hover:text-white transition-all duration-200"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>

                  <span className="text-lg font-medium text-emerald-300 min-w-[120px] text-center">
                    {currentQuarterInfo?.months[currentMonth]}
                  </span>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigateMonth("next")}
                    disabled={currentMonth === 2}
                    className="text-slate-400 hover:bg-slate-700 hover:text-white transition-all duration-200"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>

                {currentGoals.length > 0 && (
                  <div className="flex items-center gap-6 text-sm">
                    <div className="bg-slate-800/50 rounded-lg px-4 py-2">
                      <span className="text-slate-400">Completion: </span>
                      <span className="text-emerald-400 font-semibold">{getGoalProgress().percentage}%</span>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg px-4 py-2">
                      <span className="text-slate-400">Goals: </span>
                      <span className="text-white font-semibold">
                        {getGoalProgress().completed}/{getGoalProgress().total}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Add Goal Form */}
              <div className="mb-8 flex justify-center">
                <div className="flex flex-col w-full max-w-md gap-3 bg-slate-800/30 rounded-lg p-4">
                  <Input
                    placeholder="Goal name..."
                    value={newGoalName}
                    onChange={(e) => setNewGoalName(e.target.value)}
                    className="bg-slate-800/80 text-white border-slate-600 focus:border-emerald-500 placeholder:text-slate-400 transition-all duration-200 focus:ring-2 focus:ring-emerald-500/20"
                  />
                  <Input
                    placeholder="Goal description (optional)..."
                    value={newGoalDescription}
                    onChange={(e) => setNewGoalDescription(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addGoal()}
                    className="bg-slate-800/80 text-white border-slate-600 focus:border-emerald-500 placeholder:text-slate-400 transition-all duration-200 focus:ring-2 focus:ring-emerald-500/20"
                  />
                  <Button
                    onClick={addGoal}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white transition-all duration-200 hover:scale-105 shadow-lg hover:shadow-emerald-500/25"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Goal
                  </Button>
                </div>
              </div>

              {/* Goals List */}
              <div className="max-w-4xl mx-auto">
                {currentGoals.map((goal) => (
                  <div
                    key={goal.id}
                    className={`mb-4 p-6 rounded-xl border transition-all duration-300 hover:scale-[1.02] ${
                      goal.completed
                        ? "bg-emerald-500/20 border-emerald-500/50 shadow-lg shadow-emerald-500/10"
                        : "bg-slate-800/50 border-slate-600 hover:bg-slate-800/70"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-4">
                          <button
                            onClick={() => toggleGoalCompletion(goal.id)}
                            className={`h-7 w-7 rounded-full border-2 flex items-center justify-center transition-all duration-200 hover:scale-110 ${
                              goal.completed
                                ? "bg-emerald-500 border-emerald-500 shadow-lg shadow-emerald-500/25"
                                : "border-slate-500 hover:border-emerald-500 hover:bg-emerald-500/10"
                            }`}
                          >
                            {goal.completed && <X className="h-4 w-4 text-white" />}
                          </button>
                          <h3
                            className={`text-xl font-semibold transition-all duration-200 ${
                              goal.completed ? "text-emerald-300 line-through" : "text-white"
                            }`}
                          >
                            {goal.name}
                          </h3>
                        </div>
                        {goal.description && (
                          <p
                            className={`mt-3 ml-11 leading-relaxed ${goal.completed ? "text-slate-400" : "text-slate-300"}`}
                          >
                            {goal.description}
                          </p>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteGoal(goal.id)}
                        className="h-9 w-9 text-red-400 hover:bg-red-500/20 hover:text-red-300 transition-all duration-200 hover:scale-110"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                {currentGoals.length === 0 && (
                  <div className="text-center py-16 text-slate-400">
                    <Target className="h-20 w-20 mx-auto mb-6 text-slate-500" />
                    <p className="text-xl font-medium mb-2">No goals yet for {currentQuarterInfo?.name}</p>
                    <p className="text-sm">Set your first quarterly goal above to get started!</p>
                  </div>
                )}
              </div>

              {/* Quarter Info */}
              <div className="mt-12 text-center text-sm text-slate-400 bg-slate-800/30 rounded-lg p-4">
                <p className="font-medium">Setting goals for {currentQuarterInfo?.months.join(", ")}</p>
                <p className="mt-1">Each quarter starts with a clean slate • Focus on what matters most</p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
